<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/">
    <html>
      <head>
        <title>Transformación de XML a HTML</title>
      </head>
      <body>
        <h1>Títulos y fechas</h1>
        <xsl:apply-templates />
      </body>
    </html>
  </xsl:template>
  
  <xsl:template match="//titulo">
    <h2>Título: 
      <xsl:value-of select="." />
    </h2>
  </xsl:template>

  <xsl:template match="//autor">
  </xsl:template>

  <xsl:template match="//fechaPublicacion">
    <p>Fecha publicación: 
      <xsl:value-of select="@año" />
    </p>
  </xsl:template>

</xsl:stylesheet>
