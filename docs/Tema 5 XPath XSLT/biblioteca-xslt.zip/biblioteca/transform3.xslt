<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:output method="text" encoding="UTF-8" indent="yes"/>

  <!-- Regla para autor -->
  <xsl:template match="autor">
    -- Aquí viene un autor:     
    <xsl:value-of select="."/>
    -- Aquí termina un autor
  </xsl:template>

  <!-- Regla vacía para titulo -->
  <xsl:template match="titulo">
  </xsl:template>
</xsl:stylesheet>