<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:output method="text" encoding="UTF-8"/>

  <!-- Solo una regla -->
  <xsl:template match="autor">
    <!-- Pero la regla no hace nada-->
  </xsl:template>
</xsl:stylesheet>