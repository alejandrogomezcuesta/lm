<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:output method="html" encoding="UTF-8" indent="yes"/>

    <xsl:template match="/biblioteca">
        <html>
            <head>
                <title>Autores</title>
            </head>
            <body>
                <h1>Autores</h1>
                <xsl:apply-templates select="libro"/>
            </body>
        </html>
    </xsl:template>

    <!-- Regla para libro -->
    <xsl:template match="libro">
        <p><xsl:value-of select="autor"/></p>
    </xsl:template>
</xsl:stylesheet>