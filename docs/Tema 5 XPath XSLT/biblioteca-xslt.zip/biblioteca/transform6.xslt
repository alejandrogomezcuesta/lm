<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>

    <xsl:template match="libro">
        <publicacion></publicacion>
    </xsl:template>

    <!-- Regla para autor -->
    <xsl:template match="autor">
        <escritor-o-escritora><xsl:value-of select="."/></escritor-o-escritora>
    </xsl:template>

    <!-- Regla vacía para titulo -->
    <xsl:template match="titulo">
        <nombre-de-la-publicacion><xsl:value-of select="."/></nombre-de-la-publicacion>
    </xsl:template>
</xsl:stylesheet>