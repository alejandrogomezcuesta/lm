<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
    <xsl:output method="xml" encoding="UTF-8" indent="yes"/>

    <xsl:template match="/biblioteca">
        <conjunto-de-publicaciones>
            <xsl:apply-templates select="libro"/>
        </conjunto-de-publicaciones>
    </xsl:template>

    <xsl:template match="libro">
        <publicacion>
            <escritor-o-escritora>
                <xsl:value-of select="autor"/>
            </escritor-o-escritora>
            <publicacion>
                <xsl:apply-templates select="titulo"/>
            </publicacion>
        </publicacion>
    </xsl:template>
</xsl:stylesheet>