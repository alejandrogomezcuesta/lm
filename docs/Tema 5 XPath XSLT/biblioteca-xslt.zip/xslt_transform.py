#!/usr/bin/env python3
"""Apply an XSLT transformation to an XML file using lxml."""

import argparse
import sys
from pathlib import Path

from lxml import etree


class XsltTransformArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        self.print_usage(sys.stderr)
        print(
            f"{self.prog}: error: se necesitan exactamente 2 argumentos "
            "(fichero XSLT y XML de origen). "
            f"Detalle: {message}",
            file=sys.stderr,
        )
        raise SystemExit(2)


def report_error(message: str, error_log: etree._ListErrorLog | None = None) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    if error_log:
        for entry in error_log:
            print(f"  {entry.level_name} ({entry.filename}:{entry.line}): {entry.message}", file=sys.stderr)


def parse_arguments() -> argparse.Namespace:
    parser = XsltTransformArgumentParser(
        description=(
            "Aplica una transformación XSLT a un fichero XML y guarda el resultado "
            "junto al XML de origen."
        ),
        usage="%(prog)s <fichero.xslt> <origen.xml>",
    )
    parser.add_argument("xslt", type=Path, help="Fichero XSLT que define la transformación")
    parser.add_argument("source", type=Path, help="Fichero XML de origen")
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    xslt_path = args.xslt.resolve()
    source_path = args.source.resolve()

    print("=== Transformación XSLT con lxml ===")
    print(f"Hoja XSLT : {xslt_path}")
    print(f"XML origen: {source_path}")

    if not xslt_path.is_file():
        report_error(f"no se encuentra el fichero XSLT: {xslt_path}")
        return 1
    if not source_path.is_file():
        report_error(f"no se encuentra el fichero XML de origen: {source_path}")
        return 1

    try:
        print("\n[1/4] Analizando la hoja XSLT...")
        xslt_document = etree.parse(str(xslt_path))
        output_methods = xslt_document.xpath(
            "/*/xsl:output/@method",
            namespaces={"xsl": "http://www.w3.org/1999/XSL/Transform"},
        )
        output_method = output_methods[0].split(":")[-1] if output_methods else "xml"
        output_extension = {
            "html": ".html",
            "text": ".txt",
        }.get(output_method, ".xml")
        output_path = source_path.with_name(
            f"{xslt_path.stem}-{source_path.stem}{output_extension}"
        )
        print(f"Salida    : {output_path}")

        print("[2/4] Compilando la transformación...")
        transform = etree.XSLT(xslt_document)

        print("[3/4] Analizando el XML de origen...")
        source_document = etree.parse(str(source_path))

        print("[4/4] Aplicando la transformación...")
        result = transform(source_document)
        print(f"     Escribiendo el resultado en UTF-8: {output_path}")
        output_path.write_text(str(result), encoding="utf-8")
    except etree.XMLSyntaxError as error:
        report_error(f"el XML o el XSLT no tiene sintaxis válida: {error}", error.error_log)
        return 1
    except etree.XSLTParseError as error:
        report_error(f"no se pudo compilar la transformación XSLT: {error}", error.error_log)
        return 1
    except etree.XSLTApplyError as error:
        report_error(f"falló la aplicación de la transformación: {error}", transform.error_log)
        return 1
    except OSError as error:
        report_error(f"no se pudo leer o escribir un fichero: {error}")
        return 1
    except UnicodeError as error:
        report_error(f"no se pudo codificar el resultado como UTF-8: {error}")
        return 1

    print(f"\nTransformación completada correctamente: {output_path}")
    if transform.error_log:
        print("Avisos o mensajes registrados por XSLT:")
        for entry in transform.error_log:
            print(f"  {entry.level_name}: {entry.message}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
