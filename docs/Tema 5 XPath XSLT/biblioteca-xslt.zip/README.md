# Ejecutar XLST

## Con python

Necesitamos un entorno virtual en la carpeta del proyecto del Visual Studio e instalar el paquete `lxml`.

En Linux, desde bash, se haría así:

```bash
sudo apt update;
sudo apt install python3-venv;
python -m venv .venv;
source .venv/bin/activate;
python -m pip install lxml;
```

En Windows, desde PowerShell, se haría así:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install lxml
```

En Windows, desde cmd, se haría así:

```cmd
python -m venv .venv
.\.venv\Scripts\activate.bat
python -m pip install lxml
```

Después hay que ejecutar el programa [`xslt_transform.py`](xslt_transform.py). Para ejecutar ese programa hay que hacerlo desde el entorno virtual que se ha definido en el código anterior haciendo lo siguiente:

*Tiene que estar activo el entorno virtual donde esté instalado `lxml`*. Lo sabemos porque en la terminal aparece `(.venv)` al principio del prompt donde ponemos las órdenes.

La aplicación se ejecuta con python `xslt_transform.py` y recibe dos argumentos:

1. El fichero con la transformación  
2. El fichero con el XML

```sh
python xslt_transform.py <fichero_transformación> <fichero_xml>
```

El fichero de salida se crea en la misma carpeta que el XML y su nombre se forma
con el nombre del fichero XSLT, un guion y el nombre del XML. La extensión
depende del método de salida: `.html` para `method="html"`, `.txt` para
`method="text"` y `.xml` si no se especifica el método o se usa uno distinto.
Por ejemplo, `transform3.xslt` y `biblioteca.xml` generan
`transform3-biblioteca.html` si la transformación declara
`<xsl:output method="html"/>`.
